# Dot Dialer

A Nothing-style dot-matrix + liquid-glass phone app for Android 12+ (built for the Phone (2a)).
Real calls, real incoming-call popup (heads-up when in use, full-screen over the lock screen),
recents from the call log, contacts, and ~30 style controls.

## Get the APK (no Android Studio needed)
1. Create a free GitHub account and a **new empty repository** (private is fine).
2. Upload everything in this folder to the repo (Add file -> Upload files, drag the *contents*
   of the folder, including `app`, `.github`, and the `.kts` / `.properties` files).
   If `.github` is skipped by the uploader: Add file -> Create new file, name it
   `.github/workflows/build.yml`, and paste the contents of that file.
3. Open the **Actions** tab. The "Build APK" workflow runs by itself (about 5-8 minutes).
   You can also press "Run workflow".
4. Open the finished run, scroll to **Artifacts**, download `DotDialer-apk`, unzip it, and
   copy `app-debug.apk` to the phone.
5. On the phone: open the APK, allow "Install unknown apps" for your file manager/browser.

## First run
- Allow the permissions it asks for.
- Tap the **Make this your phone app** banner and choose Dot Dialer.
  That is what lets it receive real calls and show the lock-screen popup.
- Ring tone and vibration are the system's (your normal ringtone settings).

## If the build fails
Open the failed run, copy the red error lines, and send them to Claude to fix.
