package com.dotdialer

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class NdApp : Application() {
    override fun onCreate() {
        super.onCreate()
        S.init(this)
    }
}

object Store {
    lateinit var sp: SharedPreferences
    lateinit var appCtx: Context
}

interface Pf { fun ld(); fun reset() }

class IntP(val k: String, val d: Int) : Pf {
    var v by mutableIntStateOf(d)
    override fun ld() { v = Store.sp.getInt(k, d) }
    fun set(x: Int) { v = x; Store.sp.edit().putInt(k, x).apply() }
    override fun reset() { set(d) }
}

class FloatP(val k: String, val d: Float) : Pf {
    var v by mutableFloatStateOf(d)
    override fun ld() { v = Store.sp.getFloat(k, d) }
    fun set(x: Float) { v = x; Store.sp.edit().putFloat(k, x).apply() }
    override fun reset() { set(d) }
}

class BoolP(val k: String, val d: Boolean) : Pf {
    var v by mutableStateOf(d)
    override fun ld() { v = Store.sp.getBoolean(k, d) }
    fun set(x: Boolean) { v = x; Store.sp.edit().putBoolean(k, x).apply() }
    override fun reset() { set(d) }
}

object S {
    // Look
    val theme = IntP("theme", 0)            // 0 auto, 1 dark, 2 light
    val accent = IntP("accent", 0xFFFF2A2A.toInt())
    val bg = IntP("bg", 1)                  // 0 dots, 1 orbs, 2 rings, 3 plain
    val orbs = FloatP("orbs", .7f)
    val blur = FloatP("blur", 60f)
    val dotGap = FloatP("dotgap", 26f)
    val anim = BoolP("anim", true)
    // Glass
    val glass = FloatP("glass", .12f)
    val edge = FloatP("edge", .5f)
    val tint = IntP("tint", 0xFFFFFFFF.toInt())
    // Keys
    val round = FloatP("round", 50f)
    val kw = FloatP("kw", .9f)
    val keyGap = FloatP("gap", 12f)
    val numSize = FloatP("num", 30f)
    val letters = BoolP("letters", true)
    val press = IntP("press", 0)            // 0 squish, 1 glow, 2 none
    // Display
    val dispDot = FloatP("dispdot", 8f)
    val dotSize = FloatP("dotsize", .38f)
    val ghost = BoolP("ghost", true)
    val glow = FloatP("glow", .6f)
    val align = IntP("align", 1)
    val glyphBar = BoolP("gbar", true)
    val chips = BoolP("chips", true)
    val fmt = BoolP("fmt", true)
    // Call key
    val callShape = IntP("cshape", 0)       // 0 round, 1 pill, 2 square
    val callColor = IntP("ccolor", 0xFF7CFFB2.toInt())
    // Feedback + layout
    val haptics = BoolP("hap", true)
    val hapMs = FloatP("hapms", 14f)
    val sound = IntP("snd", 0)              // 0 off, 1 dtmf
    val navTop = BoolP("navtop", false)

    val all: List<Pf> = listOf(
        theme, accent, bg, orbs, blur, dotGap, anim, glass, edge, tint, round, kw, keyGap, numSize,
        letters, press, dispDot, dotSize, ghost, glow, align, glyphBar, chips, fmt, callShape,
        callColor, haptics, hapMs, sound, navTop
    )

    fun init(c: Context) {
        Store.appCtx = c.applicationContext
        Store.sp = c.getSharedPreferences("dot_dialer", Context.MODE_PRIVATE)
        all.forEach { it.ld() }
    }
}

fun applyPreset(name: String) {
    val h = S.haptics.v; val hm = S.hapMs.v; val sn = S.sound.v
    S.all.forEach { it.reset() }
    S.haptics.set(h); S.hapMs.set(hm); S.sound.set(sn)
    when (name) {
        "Mono mist" -> { S.theme.set(2); S.accent.set(0xFF111111.toInt()); S.bg.set(2); S.glass.set(.35f); S.edge.set(.8f); S.callColor.set(0xFF111111.toInt()) }
        "Glyph ice" -> { S.accent.set(0xFF4DB8FF.toInt()); S.bg.set(1); S.glass.set(.16f); S.tint.set(0xFFB8E0FF.toInt()); S.callColor.set(0xFF4DB8FF.toInt()) }
        "Lime terminal" -> { S.accent.set(0xFFB6FF3B.toInt()); S.round.set(12f); S.tint.set(0xFFB6FF3B.toInt()); S.glass.set(.06f); S.callColor.set(0xFFB6FF3B.toInt()); S.callShape.set(2) }
        "Sunset" -> { S.accent.set(0xFFFF8A3D.toInt()); S.bg.set(1); S.round.set(30f); S.tint.set(0xFFFFD2B0.toInt()); S.glass.set(.16f); S.callColor.set(0xFFFFD400.toInt()) }
    }
}
